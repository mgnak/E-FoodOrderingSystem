<?php
require_once './session.php';
require_once '../include/config.php';
require_once '../db/DB.php';
require_once '../db/DepartmentManager.php';
require_once '../db/StaffManager.php';
require_once '../db/StudentManager.php';

$departments = DepartmentManager::getDepartments();
$staffs = StaffManager::getStaffs($deptRid);
$students = StudentManager::getStudents($deptRid);
$Semister = array(1, 2, 3, 4, 5, 6);
if (isset($_POST['search'])) {
    $Sem = $_POST['sem'];
    if ($Sem == "-1") {
        $students = StudentManager::getStudents($deptRid);
    } else {
        $students = StudentManager::GetStudentBySem($Sem);
    }
}
?>

<html>
<?php require_once '../include/head.php'; ?>

<body>

    <?php require_once './staff_left_nav.php'; ?>

    <div class="container-fluid">
        <div class="row">

            <?php require_once './staff_top_bar.php'; ?>

            <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
                <div class="row">
                    <h4 class="p-2">Student</h4>
                </div>
                <form method="post" action="">
                    <div class="row d-flex align-items-center">
                        <div class="col-md-1"><span class=""><b>Filter By</b></span> </div>
                        <div class="col-md-3">
                            <select class="form-control" id="sem" name="sem">
                                <option selected value="-1">--Select Semister--</option>
                                <?php foreach ($Semister as $sem) { ?>
                                    <option value="<?php echo $sem ?>"><?php echo $sem ?> Semister</option>
                                <?php  } ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <button type="submit" name="search" class="btn btn-primary">Search</button>
                        </div>
                    </div>
                </form>
                <div class="row justify-content-end mb-2">
                    <button id="btnAddStudent" class="btn btn-primary">
                        Add Student
                    </button>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <table class="table table-bordered table-sm table-striped">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Gender</th>
                                    <th>Roll No</th>
                                    <th>D.O.B</th>
                                    <th>Contact</th>
                                    <th>Email</th>
                                    <th>Department</th>
                                    <th>Semester</th>
                                    <th>Address</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody id="StudentData">
                                <?php
                                $i = 0;
                                foreach ($students as $row) {
                                ?>
                                    <tr>
                                        <td><?php echo ++$i; ?></td>
                                        <td><?php echo $row['student_name']; ?></td>
                                        <td><?php echo $row['student_gender']; ?></td>
                                        <td><?php echo $row['student_rollno']; ?></td>
                                        <td><?php echo $row['student_dob']; ?></td>
                                        <td><?php echo $row['student_contact']; ?></td>
                                        <td><?php echo $row['student_email']; ?></td>
                                        <td><?php echo $row['name']; ?></td>
                                        <td><?php echo $row['student_sem']; ?></td>
                                        <td><?php echo $row['student_address']; ?></td>
                                        <td><?php echo $row['status'] == 1 ? 'ACTIVE' : 'INACTIVE'; ?></td>
                                        <td>
                                            <a href="#" onclick="getStudentDetails('<?php echo $row['id']; ?>')">
                                                Edit
                                            </a>
                                        </td>
                                    </tr>
                                <?php
                                }
                                if ($i == 0) {
                                ?>
                                    <tr>
                                        <td colspan="100%" class="alert alert-danger text-center">
                                            No records...
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- add/update staff modal -->
    <div id="modalAddUpdateStaff" class="modal fade" tabindex="-1" role="dialog" data-keyboard="false" data-backdrop="static">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 id="addUpdateStaffTitle" class="modal-title">Add Student</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="formAddUpdateStudent" action="../actions/admin_actions.php" method="post" onsubmit="return saveStudent();">

                        <input type="hidden" name="command" id="command" value="saveStudent" />
                        <input type="hidden" name="staffRid" id="staffRid" value="0" />
                        <input type="hidden" name="studentId" id="studentId" value="0" />

                        <div class="form-group">
                            <input type="text" class="form-control" name="student_Name" id="student_Name" placeholder="Student Name" autocomplete="off" />
                        </div>
                        <div class="form-group">
                            <input type="number" class="form-control" name="student_rollno" max="5" id="student_rollno" placeholder="Student Roll No" autocomplete="off" />
                        </div>
                        <div class="form-group">
                            <select class="form-control" id="gender" name="gender">
                                <option selected value="-1">--Select Gender--</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <small>D.O.B</small>
                            <input type="date" class="form-control" name="dateOfBirth" id="dateOfBirth" placeholder="D.O.B" autocomplete="off" />
                        </div>

                        <div class="form-group">
                            <input type="text" class="form-control" name="contact" id="contact" placeholder="Contact Number" autocomplete="off" />
                        </div>

                        <div class="form-group">
                            <input type="text" class="form-control" name="emailId" id="emailId" placeholder="Parent Email ID" autocomplete="off" />
                        </div>
                        <div class="form-group">
                            <select class="form-control" id="semister" name="semister">
                                <option selected value="-1">--Select Semister--</option>
                                <?php foreach ($Semister as $sem) { ?>
                                    <option value="<?php echo $sem ?>"><?php echo $sem ?> Semister</option>
                                <?php  } ?>

                            </select>
                        </div>

                        <div class="form-group">
                            <select class="form-control" id="department" name="department">
                                <option value="-1" <?php echo ($deptRid <= 0) ? 'selected' : 'disabled' ?>>
                                    --Select Department--
                                </option>
                                <?php foreach ($departments as $department) { ?>
                                    <option value="<?php echo $department['dept_rid']; ?>" <?php echo $department['dept_rid'] == $deptRid ? 'selected' : 'disabled' ?>>
                                        <?php echo $department['name']; ?>
                                    </option>
                                <?php } ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <textarea class="form-control" name="address" id="address" placeholder="Address"></textarea>
                        </div>
                        <div class="form-group text-right">
                            <button type="submit" id="btnSaveStudent" class="btn btn-primary">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php require_once '../include/footer.php'; ?>
    <script src="../static/js/Student.js"></script>
</body>

</html>