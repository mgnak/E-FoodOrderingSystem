<nav class="col-md-2 d-none d-md-block bg-light sidebar screen">
    <div class="sidebar-sticky">
        <ul class="nav flex-column">
            <?php if ($isHoD) { ?>
                <li class="nav-item">
                    <a class="nav-link" href="staff.php">
                        Staff
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_strength.php">
                        Students Strength
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="subject.php">
                        Subject
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="subject_allotment.php">
                        Subject Allotment
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="./Student.php">
                        Student
                    </a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="internal_sessions.php">
                    Sessions
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="upload_time_table.php">
                    Time Table
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="staff_duty.php">
                    Staff Duty Allotment
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="download_question_paper.php">
                    Download Question Paper
                </a>
            </li>
            <?php } ?>
            <?php if (!$isHoD) { ?>
                <li class="nav-item">
                    <a class="nav-link" href="alloted_subjects.php">
                        Alloted Subjects
                    </a>
                </li>
            <?php } ?>
            <li class="nav-item">
                <a class="nav-link" href="duty_list.php">
                    Staff Duty List
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="time_table.php">
                   View Time Table
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="question_paper.php">
                    Upload Quetion Paper
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="StudentMarks.php">
                    Marks
                </a>
            </li>
        </ul>
    </div>
</nav>