<?php
require_once './session.php';
require_once '../include/config.php';
require_once '../db/DB.php';
require_once '../db/StaffManager.php';

$dutyList = StaffManager::getDutyListForStaff($staffRid, $deptRid, $isHoD);
?>

<html>
    <?php require_once '../include/head.php'; ?>
    <body>

        <?php require_once './staff_left_nav.php'; ?>

        <div class="container-fluid">
            <div class="row">

                <?php require_once './staff_top_bar.php'; ?>

                <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
                    <div class="row">
                        <h4 class="p-2">Duty List</h4>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <table class="table table-bordered table-sm table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <?php if ($isHoD) { ?>
                                            <th>Staff</th>
                                        <?php } ?>
                                        <th>Internal</th>
                                        <th>Year</th>
                                        <th>Sem Type</th>
                                        <th>Session</th>
                                        <th>Session Date</th>
                                        <th>Session Time</th>
                                        <th>Room No.</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $i = 0;
                                    foreach ($dutyList as $duty) {
                                        ?>
                                        <tr>
                                            <td><?php echo ++$i; ?></td>
                                            <?php if ($isHoD) { ?>
                                                <td><?php echo $duty['staff_name']; ?></td>
                                            <?php } ?>
                                            <td><?php echo $duty['internal']; ?></td>
                                            <td><?php echo $duty['year']; ?></td>
                                            <td><?php echo $duty['is_odd_sem'] == 1 ? 'ODD' : 'EVEN'; ?></td>
                                            <td><?php echo $duty['number']; ?></td>
                                            <td><?php echo $duty['formatted_date']; ?></td>
                                            <td><?php echo $duty['formatted_time']; ?></td>
                                          <td>  <?php echo $duty['roomno']; ?></td> 
                                        </tr>
                                        <?php
                                    }
                                    if ($i == 0) {
                                        ?>
                                        <tr>
                                            <td colspan="100%" class="alert alert-danger text-center">
                                                No records...
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </main>
            </div>
        </div>

        <?php require_once '../include/footer.php'; ?>
    </body>
</html>