<?php
require_once './session.php';
require_once '../include/config.php';
require_once '../db/DB.php';
require_once '../db/StaffManager.php';
require_once '../db/SubjectManager.php';

$staffs = StaffManager::getStaffs($deptRid);
$subjects = SubjectManager::getSubjects();
$academicYears = SubjectManager::getAcademicYear();
$subjectAllotments = SubjectManager::getSubjectAllotments();
?>

<html>
    <?php require_once '../include/head.php'; ?>
    <body>

        <?php require_once './staff_left_nav.php'; ?>

        <div class="container-fluid">
            <div class="row">

                <?php require_once './staff_top_bar.php'; ?>

                <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
                    <div class="row">
                        <h4 class="p-2">Subjects Allotment</h4>
                    </div>
                    <div class="row justify-content-end mb-2">
                        <button id="btnNewAllotment"
                                class="btn btn-primary">
                            New Allotment
                        </button>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <table class="table table-bordered table-sm table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Title</th>
                                        <th>Code</th>
                                        <th>Year</th>
                                        <th>Sem</th>
                                        <th>Staff</th>
                                        <th>Department</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $i = 0;
                                    foreach ($subjectAllotments as $subject) {
                                        ?>
                                        <tr>
                                            <td><?php echo ++$i; ?></td>
                                            <td><?php echo $subject['title']; ?></td>
                                            <td><?php echo $subject['code']; ?></td>
                                            <td><?php echo $subject['year']; ?></td>
                                            <td><?php echo $subject['sem']; ?></td>
                                            <td><?php echo $subject['staff_name'] . ' [' . $subject['short_name'] . ']'; ?></td>
                                            <td><?php echo $subject['dept_name']; ?></td>
                                        </tr>
                                        <?php
                                    }
                                    if ($i == 0) {
                                        ?>
                                        <tr>
                                            <td colspan="100%" class="alert alert-danger text-center">
                                                No records...
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </main>
            </div>
        </div>

        <!-- add/update subject modal -->
        <div id="modalSubjectAllotment" class="modal fade" tabindex="-1" role="dialog"
             data-keyboard="false" data-backdrop="static">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 id="addUpdateSubjectAllotmentTitle" class="modal-title">New Allotment</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form id="formNewSubjectAllotment" action="../actions/admin_actions.php" method="post">

                            <input type="hidden" name="command" id="command" value="saveAllotment"/>
                            <input type="hidden" name="allotmentRid" id="allotmentRid" value="0"/>
                            <input type="hidden" name="department" id="department" value="<?php echo $deptRid; ?>"/>

                            <div class="form-group">
                                <select class="form-control" id="staff" name="staff">
                                    <option value="-1">--Select Staff--</option>
                                    <?php foreach ($staffs as $staff) { ?>
                                        <option value="<?php echo $staff['staff_rid'] ?>">
                                            <?php echo $staff['staff_name'] . ' [' . $staff['short_name'] . ']' ?>
                                        </option>
                                    <?php } ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <select class="form-control" id="subject" name="subject">
                                    <option value="-1">--Select Subjects--</option>
                                    <?php foreach ($subjects as $subject) { ?>
                                        <option value="<?php echo $subject['subject_rid'] ?>">
                                            <?php echo $subject['title'] ?>
                                        </option>
                                    <?php } ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <select class="form-control" id="academicYear" name="academicYear">
                                    <option value="-1">--Select Academic Year--</option>
                                    <?php foreach ($academicYears as $ay) { ?>
                                        <option value="<?php echo $ay['ay_rid']; ?>">
                                            <?php echo $ay['year'] . ' [ Sem ' . $ay['sem'] . ']'; ?>
                                        </option>
                                    <?php } ?>
                                </select>
                            </div>
                            <div class="form-group text-right">
                                <button type="submit"
                                        id="btnSaveAllotment" class="btn btn-primary">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <?php require_once '../include/footer.php'; ?>
        <script src="../static/js/subject.js"></script>
    </body>
</html>