<?php
require_once './session.php';
require_once '../include/config.php';
require_once '../db/DB.php';
require_once '../db/DepartmentManager.php';
require_once '../db/TimetableManager.php';

$internal = 0;
$sem = 0;
if (isset($_GET['internal'])) {
    $internal = $_GET['internal'];
}
if (isset($_GET['sem'])) {
    $sem = $_GET['sem'];
}

$timeTable = TimetableManager::getTimeTableForHoD($deptRid, $internal, $sem);
$department = DepartmentManager::getDepartmentDetails($deptRid);
?>

<html>
<?php require_once '../include/head.php'; ?>

<body>

    <?php require_once './staff_left_nav.php'; ?>

    <div class="container-fluid">
        <div class="row">

            <?php require_once './staff_top_bar.php'; ?>

            <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
                <div class="row screen">
                    <h4 class="p-2">Time Table</h4>
                </div>
                <div class="row screen">
                    <form action="" method="get">
                        <div class="form-inline">
                            <label class="mr-1">Internal</label>
                            <select class="form-control-sm" id="internal" name="internal">
                                <option value="1" <?php $internal == 1 ? 'selected' : ''; ?>>1</option>
                                <option value="2" <?php $internal == 2 ? 'selected' : ''; ?>>2</option>
                                <option value="3" <?php $internal == 3 ? 'selected' : ''; ?>>3</option>
                            </select>
                            <label class="mr-1 ml-2">Semister</label>
                            <select class="form-control-sm" id="sem" name="sem" required>
                                <option value="1" <?php $sem == 1 ? 'selected' : ''; ?>>1</option>
                                <option value="2" <?php $sem == 2 ? 'selected' : ''; ?>>2</option>
                                <option value="3" <?php $sem == 3 ? 'selected' : ''; ?>>3</option>
                                <option value="4" <?php $sem == 4 ? 'selected' : ''; ?>>4</option>
                                <option value="5" <?php $sem == 5 ? 'selected' : ''; ?>>5</option>
                                <option value="6" <?php $sem == 6 ? 'selected' : ''; ?>>6</option>
                            </select>
                            <button class="btn btn-primary btn-sm ml-1">
                                View Time Table
                            </button>
                        </div>
                    </form>
                </div>
                <div class="print-area">
                    <?php if ($internal > 0) { ?>
                        <div class="row">
                            <table class="table table-borderless table-sm">
                                <tr>
                                    <td class="text-center">
                                        <strong><?php echo COLLEGE_Name ?></strong>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="text-center">
                                        <strong>Department of <?php echo $department['name']; ?></strong>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="text-center">
                                        <strong>
                                            <?php
                                            if ($internal == 1) {
                                                echo "First";
                                            } else if ($internal == 2) {
                                                echo "Second";
                                            } else if ($internal == 3) {
                                                echo "Third";
                                            }
                                            ?>
                                            Internal Time Table
                                        </strong>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    <?php } ?>
                    <div class="row">
                        <table class="table table-bordered table-sm">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Sem</th>
                                    <th>Subject</th>
                                    <th>Date</th>
                                    <th>Time</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $i = 0;
                                foreach ($timeTable as $tt) {
                                ?>
                                    <tr>
                                        <td><?php echo ++$i; ?></td>
                                        <td><?php echo $tt['sem']; ?></td>
                                        <td><?php echo $tt['title']; ?></td>
                                        <td><?php echo $tt['formatted_date']; ?></td>
                                        <td><?php echo $tt['formatted_time']; ?></td>
                                    </tr>
                                <?php
                                }
                                if ($i == 0) {
                                ?>
                                    <tr>
                                        <td colspan="100%" class="alert alert-danger text-center">
                                            No records...
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php if ($i != 0) { ?>
                    <div class="row my-5 print-area">
                        <table class="table table-borderless">
                            <tr>
                                <td class="text-center">
                                    <strong>Principal</strong>
                                </td>
                                <td class="text-center">
                                    <strong>HOD</strong>
                                </td>
                            </tr>
                        </table>
                    </div>
                    <?php if ($isHoD) { ?>
                        <div class="row justify-content-center screen">
                            <button id="btnPrint" class="btn btn-primary">
                                Print
                            </button>
                        </div>
                    <?php } ?>
                <?php } ?>
            </main>
        </div>
    </div>

    <?php require_once '../include/footer.php'; ?>
    <script src="../static/js/time_table.js"></script>
</body>

</html>