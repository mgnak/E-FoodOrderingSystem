<?php
require_once './session.php';
require_once '../include/config.php';
require_once '../db/DB.php';
require_once '../db/SubjectManager.php';
require_once '../db/StudentManager.php';

$value = $_GET['semister'];
$semister = explode(",", $value);
$subid = $semister[1];
$sem = $semister[0];
$internal = 1;


if (isset($_GET['internal'])) {
    $internal = $_GET['internal'];
}

$count = 0;

$Students = StudentManager::GetStudentBySem($sem);
$StudentsMarks = StudentManager::GetStudentByMarks($sem, $subid, $internal);

if (count($StudentsMarks) > 0) {
    $temp = 1;
} else {
    $temp = 0;
}

function getData()
{
}
// if(count($Students)>0){
//     $marsk=
// }
?>
<div class="">
    <div class="container">

        <form id="SaveStudentsMark" method="post" action="../actions/admin_actions.php" onsubmit="return SaveStudentsMark(event);">
            <input type="hidden" value="SaveMarks" name="command">
            <input type="hidden" value="<?php echo $semister[1] ?>" name="subjectid" id="subjectid">
            <input type="hidden" value="<?php echo $semister[0] ?>" name="semi" id="semi">
            <input type="hidden" value="<?php echo $semister[2] ?>" name="year" id="year">
            <div class="form-group mx-1">
                <label for="exampleFormControlInput1" class="form-label text2"><b>Select Internal</b></label>

                <select class="form-control" id="internal" name="internal" onchange="getMarks(this.value,'<?php echo $sem ?>','<?php echo $subid ?>','<?php echo $count ?>');">
                    <option value="1" <?php $internal == 1 ? 'selected' : ''; ?>>1</option>
                    <option value="2" <?php $internal == 2 ? 'selected' : ''; ?>>2</option>
                    <option value="3" <?php $internal == 3 ? 'selected' : ''; ?>>3</option>
                </select>

            </div>

            <?php
            if ($temp == 0) {
                foreach ($Students as $row) {
                    $count++ ?>
                    <div class="row my-2 ml-5">
                        <div class="col-md-4">
                            <label style="font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;"><b><?php echo $row['student_name'] ?> [<?php echo $row['student_rollno'] ?>]</b></label>
                        </div>

                        <div class="col-md-6">
                            <input type="number" id="Mark<?php echo $count ?>" name="<?php echo $row['id'] ?>" class="form-control dynamicInput" min="0" max="25" aria-describedby="passwordHelpBlock" placeholder="Marks" required>
                            <!-- <input type="hidden" id="StudentId" name="" class="form-control dynamicId" value="<?php echo $row['id'] ?>" aria-describedby="passwordHelpBlock" placeholder="Marks" required> -->
                        </div>
                    </div>
                <?php }
            } else {
                foreach ($StudentsMarks as $row) {
                    $count++
                ?>
                    <div class="row my-2 ml-5" id="marksdata">
                        <div class="col-md-4" id="names">
                            <label style="font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;"><b><?php echo $row['student_name'] ?> [<?php echo $row['student_rollno'] ?>]</b></label>
                        </div>

                        <div class="col-md-6" id="values">
                            <input type="number" id="Mark<?php echo $count ?>" name="<?php echo $row['id'] ?>" class="form-control dynamicInput" value="<?php echo $row['marks'] ?>" aria-describedby="passwordHelpBlock" placeholder="Marks" required>
                            <!-- <input type="hidden" id="StudentId" name="" class="form-control dynamicId" value="<?php echo $row['id'] ?>" aria-describedby="passwordHelpBlock" placeholder="Marks" required> -->
                        </div>
                    </div>
            <?php }
            } ?>
            <div class=" my-4 ml-5">
                <div class="ml-1"></div>
                <button type="submit" class="btn btn-primary px-5 w-75 ml-4" id="SaveStudentsMarks">Save</button>

            </div>
        </form>
    </div>
</div>
<script src="../static/js/Student.js"></script>