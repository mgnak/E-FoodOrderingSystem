<?php
require_once './session.php';
require_once '../include/config.php';
require_once '../db/DB.php';
require_once '../db/DepartmentManager.php';
require_once '../db/StaffManager.php';

$departments = DepartmentManager::getDepartments();
$staffs = StaffManager::getStaffs($deptRid);
?>

<html>
    <?php require_once '../include/head.php'; ?>
    <body>

        <?php require_once './staff_left_nav.php'; ?>

        <div class="container-fluid">
            <div class="row">

                <?php require_once './staff_top_bar.php'; ?>

                <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
                    <div class="row">
                        <h4 class="p-2">Staff</h4>
                    </div>
                    <div class="row justify-content-end mb-2">
                        <button id="btnAddStaff"
                                class="btn btn-primary">
                            Add Staff
                        </button>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <table class="table table-bordered table-sm table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Contact</th>
                                        <th>Department</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $i = 0;
                                    foreach ($staffs as $staff) {
                                        ?>
                                        <tr>
                                            <td><?php echo ++$i; ?></td>
                                            <td><?php echo $staff['staff_name']; ?></td>
                                            <td><?php echo $staff['contact']; ?></td>
                                            <td><?php echo $staff['dept_name']; ?></td>
                                            <td><?php echo $staff['staff_status'] == 1 ? 'ACTIVE' : 'INACTIVE'; ?></td>
                                            <td>
                                                <a href="#"
                                                   onclick="getStaffDetails('<?php echo $staff['staff_rid']; ?>')">
                                                    Edit
                                                </a>
                                            </td>
                                        </tr>
                                        <?php
                                    }
                                    if ($i == 0) {
                                        ?>
                                        <tr>
                                            <td colspan="100%" class="alert alert-danger text-center">
                                                No records...
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </main>
            </div>
        </div>

        <!-- add/update staff modal -->
        <div id="modalAddUpdateStaff" class="modal fade" tabindex="-1" role="dialog"
             data-keyboard="false" data-backdrop="static">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 id="addUpdateStaffTitle" class="modal-title">Add Staff</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form id="formAddUpdateStaff" action="../actions/admin_actions.php" method="post">

                            <input type="hidden" name="command" id="command" value="saveStaff"/>
                            <input type="hidden" name="staffRid" id="staffRid" value="0"/>

                            <div class="form-group">
                                <input type="text" class="form-control" name="staffName" id="staffName"
                                       placeholder="Staff Name" autocomplete="off"/>
                            </div>

                            <div class="form-group">
                                <input type="text" class="form-control" name="shortName" id="shortName"
                                       placeholder="Short Name" autocomplete="off"/>
                            </div>

                            <div class="form-group">
                                <input type="text" class="form-control" name="contact" id="contact"
                                       placeholder="Contact Number" autocomplete="off"/>
                            </div>

                            <div class="form-group">
                                <input type="text" class="form-control" name="emailId" id="emailId"
                                       placeholder="Email ID" autocomplete="off"/>
                            </div>

                            <div class="form-group">
                                <input type="password" class="form-control" name="password" id="password"
                                       placeholder="Password" autocomplete="off"/>
                            </div>

                            <div class="form-group">
                                <select class="form-control" id="department" name="department">
                                    <option value="-1"
                                            <?php echo ($deptRid <= 0) ? 'selected' : 'disabled' ?>>
                                        --Select Department--
                                    </option>
                                    <?php foreach ($departments as $department) { ?>
                                        <option value="<?php echo $department['dept_rid']; ?>"
                                                <?php echo $department['dept_rid'] == $deptRid ? 'selected' : 'disabled' ?>>
                                                    <?php echo $department['name']; ?>
                                        </option>
                                    <?php } ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <textarea class="form-control" name="address" id="address"
                                          placeholder="Address"></textarea>
                            </div>

                            <div class="form-group">
                                <input type="checkbox" name="isActive" id="isActive"
                                       checked="checked" value="1"/>
                                <label for="isActive">is active?</label>
                            </div>

                            <div class="form-group text-right">
                                <button type="submit"
                                        id="btnSaveStaff" class="btn btn-primary">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <?php require_once '../include/footer.php'; ?>
        <script src="../static/js/staff.js"></script>
    </body>
</html>