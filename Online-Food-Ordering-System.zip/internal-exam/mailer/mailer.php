<?php

require_once '../mailer/Exception.php';
require_once '../mailer/PHPMailer.php';
require_once '../mailer/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

function sendMail($subject, $imageData, $toAddress,$mailContent)
{

    try {

        $mail = new PHPMailer(true);

        //        $mail->SMTPDebug = SMTP::DEBUG_SERVER;
        $mail->isSMTP();                                      // Set mailer to use SMTP
        $mail->Host = 'smtp.gmail.com';                         // Specify main and backup SMTP servers
        $mail->SMTPAuth = true;                               // Enable SMTP authentication
        $mail->Username = 'karthikkumarh733@gmail.com';                 // SMTP username
        $mail->Password = 'ivxlkwvmoopnjzws';                           // SMTP password
        $mail->SMTPSecure = 'tls';                            // Enable encryption, 'ssl' also accepted
        $mail->Port = 587;
        $mail->SMTPOptions = array(
            'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            )
        );

        $mail->From = 'karthikkumarh733@gmail.com';
        $mail->FromName = PROJECT_NAME;
        $mail->addAddress($toAddress, '');

        $mail->WordWrap = 50;                                 // Set word wrap to 50 characters
        $mail->isHTML(true);                                  // Set email format to HTML

        $mail->Subject = $subject;
        $mail->Body = $mailContent;
        $mail->AltBody =$mailContent;

        $imageFile = './image.png';
        file_put_contents($imageFile, base64_decode(str_replace('data:image/png;base64,', '', $imageData)));

        // Attach the image file to the email
        $mail->addAttachment($imageFile, 'image.png');

        if (!$mail->send()) {
            throw new Exception('Message could not be sent.: ' . $mail->ErrorInfo);
        } else {
            return true;
        }
    } catch (Exception $ex) {
        throw $ex;
    }
}
