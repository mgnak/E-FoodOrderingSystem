<?php
require_once './include/config.php';
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>
            <?php echo PROJECT_NAME; ?>
        </title>
        <link href="static/css/bootstrap.min.css" rel="stylesheet">
        <link href="static/css/custom.css" rel="stylesheet">
    </head>
    <body class="index">
        <nav class="navbar navbar-expand-lg navbar-light">
            <a class="navbar-brand text-white" href="#">
                <?php echo PROJECT_NAME; ?>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                    aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link text-white bg-warning" href="Student/login.php">Student Login</a>
                    </li>
                    <li class="nav-item ml-2">
                        <a class="nav-link text-white bg-warning" href="login.php">Login</a>
                    </li>
                </ul>
            </div>
        </nav>

        <div class="container">
            <div class="jumbotron jumbotron-transparent text-center my-4">
                <h1 class="text-white">Welcome to <?php echo PROJECT_NAME; ?>!</h1>
               
            </div>
        </div>

        <script src="static/js/jquery.min.js"></script>
        <script src="static/js/bootstrap.bundle.min.js"></script>
    </body>
</html>
