<?php

use function PHPSTORM_META\type;

class StudentManager
{


    public static function AddEditStudent($name, $gender, $dob, $contact, $email, $sem, $address, $departmrnt, $studentid,$student_rollno)
    {

        if ($studentid == 0) {
            $randomNumber = mt_rand(10000, 99999);

            $insert = "INSERT INTO `student`(student_name,student_gender,student_dob,student_contact,student_email,student_sem,student_address,student_department,student_rollno)
            VALUES('$name','$gender','$dob','$contact','$email','$sem','$address','$departmrnt',$student_rollno)";

            return DB::insertAndGetId($insert);
        } else {
            $update = "UPDATE student SET
            student_name = '$name',
            student_gender = '$gender',
            student_dob = '$dob',
            student_rollno = '$student_rollno',
            student_contact = '$contact',
            student_email = '$email',
            student_sem = '$sem',
            student_address = '$address',
            student_department = '$departmrnt'
            WHERE id = $studentid";
            return DB::update($update);
        }
    }

    public static function getStudents($deptRid)
    {
        $select = "SELECT * FROM `student`JOIN department ON department.dept_rid=student.student_department WHERE student_department=$deptRid";
        return DB::selectAll($select);
    }
    public static function getStudentsStrength()
    {
        $sql = "SELECT *,"
            . " d.name AS dept_name"
            . " FROM student_strength AS ss"
            . " LEFT JOIN department AS d ON (ss.dept_rid = d.dept_rid)"
            . " WHERE ss.status = 1";
        return DB::selectAll($sql);
    }

    public static function saveStudentStrength($ssRid, $academicYear, $department, $totalStudents, $isActive)
    {

        $ay = SubjectManager::getAcademicYearDetails($academicYear);

        $year = $ay['year'];
        $sem = $ay['sem'];

        if ($ssRid > 0) {
            $sql = "UPDATE student_strength SET `year` = $year, sem = $sem, dept_rid = $department,"
                . " total_students = $totalStudents, `status` = $isActive"
                . " WHERE ss_rid = $ssRid";
            return DB::update($sql);
        } else {

            if (self::isStrengthAlreadyExists($year, $sem, $department)) {
                throw new Exception("Already exists");
            }

            $sql = "INSERT INTO student_strength(`year`, sem, dept_rid, total_students, `status`, created_at)"
                . " VALUES('$year', '$sem', '$department', '$totalStudents', '$isActive', NOW())";
            return DB::insertAndGetId($sql);
        }
    }

    public static function isStrengthAlreadyExists($year, $sem, $department)
    {
        $sql = "SELECT 1 FROM student_strength"
            . " WHERE year = $year AND sem = $sem AND dept_rid = $department";
        $res = DB::selectOne($sql);
        return !empty($res);
    }

    public static function getStudentStrengthDetails($strengthRid)
    {
        $sql = "SELECT * FROM student_strength"
            . " WHERE ss_rid = $strengthRid";
        return DB::selectOne($sql);
    }

    public static function GetStudentBYId($id)
    {
        $sql = "SELECT * FROM student WHERE id = $id";
        return DB::selectOne($sql);
    }

    public static function GetStudentBySem($semister)
    {
        $sql = "SELECT * FROM `student` JOIN department ON department.dept_rid=student.student_department WHERE student_sem = '$semister'";
        return DB::selectAll($sql);
    }
    public static function GetStudentByMarks($semister, $subid, $internal)
    {
        $select = "SELECT * FROM marks JOIN  student ON student.id=marks.student_id WHERE sem='$semister' AND subject_id='$subid' AND internal=$internal";
        return DB::selectAll($select);
    }

    public static function SaveMarks($marks)
    {
        $res = null;
        foreach ($marks as $row) {
            $StudentId = $row['StudentID'];
            $SubjectId = $row['SubjectID'];
            $Internal = $row['internal'];
            $Marks = $row['Marks'];
            $Sem = $row['Semister'];
            $Year = $row['Year'];

            $select = "SELECT * FROM marks WHERE student_id=$StudentId AND internal=$Internal AND sem=$Sem AND subject_id=$SubjectId";
            $Result = DB::selectOne($select);
            if ($Result > 0) {
                $id = $Result['mark_id'];
                $Update = "UPDATE marks SET marks = $Marks WHERE mark_id = $id";
                DB::update($Update);
                $res = 1;
            } else {
                $query = "INSERT INTO marks (subject_id,student_id,internal,marks,sem,year) VALUES ($SubjectId,$StudentId,$Internal,$Marks,$Sem,$Year)";
                $res = DB::insertAndGetId($query);
            }
        }

        return $res;
    }
    
    
    public static function GetStudentByContact($contact,$student_rollno)
    {
        $sql = "SELECT * FROM `student` WHERE student_contact = '$contact' AND student_rollno=$student_rollno";
        return DB::selectAll($sql);
    }
    public static function GetStudentByEmail($emailId)
    {
        $sql = "SELECT * FROM `student` WHERE student_email = '$emailId'";
        return DB::selectAll($sql);
    }
    public static function GetStudentByUsername($username)
    {
        $sql = "SELECT * FROM `student` WHERE student_rollno = '$username'";
        return DB::selectOne($sql);
    }
    public static function UpdateStudent($contact, $password)
    {
        $sql = "update student set  Student_password='$password' where student_contact='$contact'";
        return DB::update($sql);
    }
    public static function StudentLogin($student_rollno, $password)
    {
        $sql = "select * from student where student_rollno='$student_rollno' and Student_password='$password'";
        return DB::selectAll($sql);
    }
    
}
