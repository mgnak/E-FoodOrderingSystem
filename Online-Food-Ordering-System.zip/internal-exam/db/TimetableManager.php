<?php

class TimetableManager {

    public static function saveTimeTable($session, $semType, $academicYear, $internal, $departments, $sems, $subjects) {

        $sql = "INSERT INTO time_table(session_rid, is_odd_sem, `year`, "
                . "dept_rid, sem, subject_rid, internal, created_at)"
                . " VALUES";

        for ($i = 0; $i < sizeof($departments); $i++) {

            if ($i > 0) {
                $sql .= ", ";
            }
            $select = "SELECT * FROM subject_allotment WHERE subject_rid=$subjects[$i]";
            $res = DB::selectAll($select);
            
            $semister=$res[0]['sem'];

            $sql .= " ($session, $semType, $academicYear, $departments[$i],$semister, $subjects[$i], $internal, NOW())";
        }

        return DB::insertAndGetId($sql);
    }

    public static function saveDuty($semType, $internal, $academicYear, $staffs, $sessions, $roomno) {

        $sql = "INSERT INTO staff_duty(`year`, internal, is_odd_sem, "
                . "session_rid, staff_rid, roomno, created_at)"
                . " VALUES";
        date_default_timezone_set('Asia/Kolkata');
        $currentDateTime = date('Y-m-d H:i:s');
        for ($i = 0; $i < sizeof($staffs); $i++) {

            if ($i > 0) {
                $sql .= ", ";
            }

            $sql .= " ('$academicYear', '$internal', '$semType', '$sessions[$i]', '$staffs[$i]', $roomno[$i] ,'$currentDateTime')";
        }

        return DB::insertAndGetId($sql);
    }

    public static function getTimeTableForHoD($deptRid, $internal,$sem) {
        $sql = "SELECT *,"
                . " DATE_FORMAT(`date`, '%d %M %Y') AS formatted_date,"
                . " DATE_FORMAT(`time`, '%h:%i %p') AS formatted_time"
                . " FROM time_table AS tt"
                . " JOIN department AS d ON (tt.dept_rid = d.dept_rid)"
                . " JOIN `subject` AS sub ON (tt.subject_rid = sub.subject_rid)"
                . " JOIN `session` AS ses ON (tt.session_rid = ses.session_rid)"
                . " WHERE tt.dept_rid = $deptRid AND tt.internal = $internal AND tt.sem=$sem" 
                . " ORDER BY sem, internal";
        return DB::selectAll($sql);
    }

    public static function getTimeTableForStudent($semister, $internal) {
        $sql = "SELECT *,"
                . " DATE_FORMAT(`date`, '%d %M %Y') AS formatted_date,"
                . " DATE_FORMAT(`time`, '%h:%i %p') AS formatted_time"
                . " FROM time_table AS tt"
                . " JOIN department AS d ON (tt.dept_rid = d.dept_rid)"
                . " JOIN `subject` AS sub ON (tt.subject_rid = sub.subject_rid)"
                . " JOIN `session` AS ses ON (tt.session_rid = ses.session_rid)"
                . " WHERE tt.sem = $semister AND tt.internal = $internal"
                . " ORDER BY sem, internal";

        return DB::selectAll($sql);
    }

    public static function AcademicYear() {
        $sql = "SELECT DISTINCT year FROM academic_year";
        return DB::selectAll($sql);
    }

    public static function getTimeMarksForStudent($internal, $year, $semister, $id) {
        $sql = "SELECT * FROM marks JOIN student ON student.id=marks.student_id
        JOIN `subject` ON subject.subject_rid=marks.subject_id
        WHERE marks.sem=$semister AND marks.year= $year AND marks.internal=$internal AND marks.student_id=$id
        ORDER BY marks.student_id ASC";
        return DB::selectAll($sql);
    }

}
