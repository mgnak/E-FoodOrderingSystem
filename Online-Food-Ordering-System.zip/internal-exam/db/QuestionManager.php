<?php

class QuestionManager {

    public static function saveQuestion($subject, $year, $internal, $infoText, $questionNo, $questionBody, $questionMarks, $staffRid, $deptRid) {

        $qhRid = self::getQuestionHeaderRid($staffRid, $subject, $year, $internal);

        if ($qhRid <= 0) {

            $infoText = str_replace("'", "\'", $infoText);

            $sql = "INSERT INTO question_header(staff_rid, subject_rid, dept_rid, `year`, internal, info_text, created_at)"
                    . " VALUES('$staffRid', '$subject', '$deptRid', '$year', '$internal', '$infoText', NOW())";

            $qhRid = DB::insertAndGetId($sql);
        }

        $questionBody = str_replace("'", "\'", $questionBody);

        $sql = "INSERT INTO question_detail(qh_rid, question_no, question, mark, created_at)"
                . " VALUES('$qhRid', '$questionNo', '$questionBody', '$questionMarks', NOW())";

        return DB::insertAndGetId($sql);
    }

    public static function getQuestionHeaderRid($staffRid, $subjectRid, $year, $internal) {
        $sql = "SELECT qh_rid FROM question_header"
                . " WHERE staff_rid = $staffRid AND subject_rid = $subjectRid"
                . " AND `year` = $year AND internal = $internal";

        $res = DB::selectOne($sql);

        if (!empty($res)) {
            return $res['qh_rid'];
        } else {
            return 0;
        }
    }

    public static function getQuestionPaperHeader($year, $department, $subject, $internal) {

    }

    public static function getQuestionsPaperForAdmin($year, $department, $subject, $internal) {
        $sql = "SELECT * FROM question_detail AS qd"
                . " JOIN question_header AS qh ON (qd.qh_rid = qh.qh_rid)"
                . " WHERE qh.year = $year AND qh.dept_rid = $department AND qh.subject_rid = $subject AND qh.internal = $internal"
                . " ORDER BY qd.qd_rid ASC";
        return DB::selectAll($sql);
    }

}
