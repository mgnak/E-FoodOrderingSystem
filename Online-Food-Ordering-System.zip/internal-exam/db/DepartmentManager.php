<?php

class DepartmentManager {

    public static function getDepartments() {
        $sql = "SELECT * FROM department"
                . " WHERE `status` = 1"
                . " ORDER BY `name`";
        return DB::selectAll($sql);
    }

    public static function getDepartmentDetails($deptRid) {
        $sql = "SELECT * FROM department"
                . " WHERE dept_rid = $deptRid";
        return DB::selectOne($sql);
    }

}
