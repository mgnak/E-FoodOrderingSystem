var rowCount = 1;

$(function () {

    // create new row
    $('#btnAddNewRow').click(function (evt) {
        evt.preventDefault();

        rowCount++;

        var content = $('#selectionRow').clone().prop('id', 'selectionRow' + rowCount);
        $('#tempRow').append(content);

    });

    $('#btnSaveDuty').click(function (evt) {
        evt.preventDefault();

        if (!confirm("Are you sure want to submit? \nThis action cannot be undone")) {
            return false;
        }

        $.ajax({
            url: $('#formStaffDuty').prop('action'),
            type: $('#formStaffDuty').prop('method'),
            data: $('#formStaffDuty').serialize(),
            success: function (data, textStatus, jqXHR) {

                if (data.success) {
                    alert(data.body);
                    location.reload();
                } else {
                    alert(data.error);
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                alert(errorThrown);
            }
        });
    });
});