$(function () {

    $('#btnSaveQuestion').click(function (evt) {
        evt.preventDefault();

        saveQuestion();
    });
    // $('#PrintQuestionPaper').click(function (evt) {
    //     evt.preventDefault();
    //     window.print();
    // var tableData = '<table border="1">' + document.getElementById('myTable').innerHTML + '</table>';
    // var data = '<button id="printPageButton" onclick="window.print()">Print this page</button>' + tableData;
    // myWindow = window.open('QuetionPaper', '', 'width=800,height=600');
    // myWindow.innerWidth = screen.width;
    // myWindow.innerHeight = screen.height;
    // myWindow.screenX = 0;
    // myWindow.screenY = 0;
    // myWindow.document.write(data);
    // myWindow.focus();
    // });

});

$('#PrintQuestionPaper').click(function (evt) {
    evt.preventDefault();
    var content = $('#printContent').html();
    var printWindow = window.open('', '_blank');
    printWindow.document.open();
    printWindow.document.write('<html><head> <link href="../static/css/bootstrap.min.css" rel="stylesheet"><link href="../static/css/dashboard.css" rel="stylesheet"><link href="../static/css/custom.css" rel="stylesheet"> <title>Print</title></head><body class="mb-5">');
    printWindow.document.write(content);
    printWindow.document.write('</body></html>');
    printWindow.document.close();
    printWindow.print();
});

function saveQuestion() {

    var subject = $('#subject').val();
    var year = $('#year').val();
    var internal = $('#internal').val();
    var infoText = $('#infoText').val();
    var questionNo = $('#questionNo').val();
    var questionBody = $('#questionBody').val();
    var questionMarks = $('#questionMarks').val();
//    var questionLevel = $('#questionLevel').val();

    if (subject === "-1") {
        alert("Please select subject");
        return false;
    }

    if (year === "-1") {
        alert("Please select year");
        return false;
    }

    if (internal === "-1") {
        alert("Please select internal");
        return false;
    }

    if (infoText === "") {
        alert("Please enter info text");
        return false;
    }

    if (questionNo === "") {
        alert("Please enter question number");
        return false;
    }

    if (questionBody === "") {
        alert("Please enter question body");
        return false;
    }

    if (questionMarks === "" || isNaN(questionMarks) || questionMarks.length > 2) {
        alert("Please enter valid question marks");
        return false;
    }

//    if (questionLevel === "-1") {
//        alert("Please select level");
//        return false;
//    }

    if (!confirm("This operation can'not be reverted back.\nAre you sure want to continue?")) {
        return false;
    }

    $.ajax({
        url: $('#formQuestionPaper').prop('action'),
        type: $('#formQuestionPaper').prop('method'),
        data: $('#formQuestionPaper').serialize(),
        success: function (data, textStatus, jqXHR) {

            if (data.success) {
                alert(data.body);

                var questionRow = "<tr><td>" + questionNo + "</td><td>" + questionBody + "</td><td>" + questionMarks +  "</td></tr>";

                $('#tblQuestion > tbody').append(questionRow);

                $('#questionNo').val("");
                $('#questionBody').val("");
                $('#questionMarks').val("");
                // $('#questionLevel').val("-1");

            } else {
                alert(data.error);
            }

        },
        error: function (jqXHR, textStatus, errorThrown) {
            alert(errorThrown);
            console.log(errorThrown);
        }
    });
}

function validateViewQuestionForm() {

    var year = $('#year').val();
    var department = $('#department').val();
    var subject = $('#subject').val();
    var internal = $('#internal').val();

    if (year === "-1") {
        alert("Please select year");
        return false;
    }

    if (department === "-1") {
        alert("Please select department");
        return false;
    }

    if (subject === "-1") {
        alert("Please select subject");
        return false;
    }

    if (internal === "-1") {
        alert("Please select internal");
        return false;
    }

    return true;
}