$(function () {
  $("#btnAddStudent").click(function (evt) {
    evt.preventDefault();
    $("#formAddUpdateStudent")[0].reset();
    $("#staffRid").val(0);
    $("#command").val("saveStudent");

    $("#addUpdateStaffTitle").text("Add Student");
    $("#modalAddUpdateStaff").modal("show");
  });

  $("#SaveMarks").click(function (evt) {
    evt.preventDefault();
    var marks = $('input[name="marks"]');

    $.ajax({
      url: "../actions/admin_actions.php",
      type: "post",
      data: {
        marks: marks.val(),
        subjectid: $("#subjectid").val(),
        internal: $("#internal").val(),
        semester: $("#sem").val(),
        year: $("#year").val(),
        command: "SaveMarks",
      },
      success: function (data, textStatus, jqXHR) {
        alert(data);
      },
      error: function (jqXHR, textStatus, errorThrown) {
        alert(errorThrown);
      },
    });
  });

  // $(document).on('input', '.dynamicInput', function() {
  //     var inputValue = $(this).val();
  //     console.log(inputValue);
  //   });

  //   $('#SaveStudentsMark').submit(function(e) {
  //     e.preventDefault();

  //   });
});

$(function () {
  $("#btnSaveStudent").click(function (evt) {
    evt.preventDefault();
    var student = studentValidation();
    if (student == true) {
      var data = $("#formAddUpdateStudent").serialize();
      console.log(data);

      $.ajax({
        url: "../actions/admin_actions.php",
        type: "post",
        datatype: "json",
        data: data,
        success: function (data, textStatus, jqXHR) {
          console.log(data);
          if (data.success) {
            alert(data.body);
            window.location.reload();
          } else {
            alert(data.error);
          }
        },
        error: function (jqXHR, textStatus, errorThrown) {
          alert(errorThrown);
          console.log(errorThrown);
        },
      });
    }
  });
});

function studentValidation() {
  var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  var nameRegex = /^[a-zA-Z- ]+$/;

  var student_Name = $("#student_Name").val();
  var student_rollno = $("#student_rollno").val();
  var gender = $("#gender").val();
  var dateOfBirth = $("#dateOfBirth").val();
  var contact = $("#contact").val();
  var emailId = $("#emailId").val();
  var semister = $("#semister").val();
  var department = $("#department").val();
  var address = $("#address").val();

  if (student_Name === "") {
    alert("Please enter name");
    return false;
  }
  if (!nameRegex.test(student_Name)) {
    alert("Name Should contain letter and white spaces");
    return false;
  }

  if (student_rollno == "") {
    alert("Please enter student rollno");
    return false;
  }
  if(student_rollno <5){
    alert("Roll no should be at least 5 digits");
    return false;
  }
  if (gender === "-1") {
    alert("Please select gender");
    return false;
  }
  if (dateOfBirth === "") {
    alert("Please select date of birth");
    return false;
  }

  if (contact === "" || contact.length !== 10 || isNaN(contact)) {
    alert("Please enter valid 10 digits contact");
    return false;
  }

  if (!emailPattern.test(emailId)) {
    alert("Please enter valid email");
    return false;
  }
  if (semister === "-1") {
    alert("Please select semester");
    return false;
  }

  if (department === "-1") {
    alert("Please select department");
    return false;
  }

  if (address === "") {
    alert("Please enter address");
    return false;
  }

  return true;
}

function getStudentDetails(studentId) {
  $("#formAddUpdateStudent")[0].reset();
  $("#staffRid").val(0);
  $("#command").val("EditStudent");
  $("#addUpdateStaffTitle").text("Edit Student");

  $.ajax({
    url: "../actions/admin_actions.php",
    type: "get",
    data: { id: studentId, command: "EditStudent" },
    success: function (data, textStatus, jqXHR) {
      console.log(data.body);
      var student = data.body;
      $("#student_Name").val(student.student_name);
      $("#gender").val(student.student_gender);
      $("#dateOfBirth").val(student.student_dob);
      $("#contact").val(student.student_contact);
      $("#emailId").val(student.student_email);
      $("#semister").val(student.student_sem);
      $("#department").val(student.student_department);
      $("#address").val(student.student_address);
      $("#student_rollno").val(student.student_rollno);
      $("#studentId").val(studentId);

      $("#command").val("UpdateStudent");

      $("#modalAddUpdateStaff").modal("show");
    },
    error: function (jqXHR, textStatus, errorThrown) {
      alert(errorThrown);
    },
  });
}

function GetStudents(semister) {
  if (semister == "-1") {
    $("#myDIV").html("");
  } else {
    $.ajax({
      url: "customAddMarks.php",
      type: "get",
      data: { semister: semister },
      success: function (data, textStatus, jqXHR) {
        $("#myDIV").html(data);
      },
      error: function (jqXHR, textStatus, errorThrown) {
        alert(errorThrown);
      },
    });
  }
}

function SaveStudentsMark(evt) {
  evt.preventDefault();
  var marksArray = [];
  $(".dynamicInput").each(function () {
    var inputValue = $(this).val();
    var inputid = $(this).prop("name");
    data = {
      Marks: inputValue,
      StudentID: inputid,
      Semister: $("#semi").val(),
      SubjectID: $("#subjectid").val(),
      Year: $("#year").val(),
      internal: $("#internal").val(),
    };
    marksArray.push(data);
  });
  console.log(marksArray);

  $.ajax({
    url: "../actions/admin_actions.php",
    type: "post",
    data: { command: "SaveMarks", MarksData: marksArray },
    success: function (data, textStatus, jqXHR) {
      if (data.success) {
        alert(data.body);
        // location.reload();
      } else {
        alert(data.error);
      }
    },
    error: function (jqXHR, textStatus, errorThrown) {
      alert(errorThrown);
    },
  });
}
