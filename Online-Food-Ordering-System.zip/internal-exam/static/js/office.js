$(function () {
    $('#sendTimeTableMail').click(function (evt) {
        evt.preventDefault();
        var semister = $('#semi').val();
        html2canvas(document.querySelector('#time_tableData'))
            .then(function (canvas) {
                var image = canvas.toDataURL();
                var imageString = btoa(image);
                $.ajax({
                    url: '../actions/admin_actions.php',
                    type: 'post',
                    data: {
                        content: image,
                        command: 'SentTimeTableInMail',
                        semister: semister
                    },
                    success: function (data, textStatus, jqXHR) {

                        console.log(data.error);
                        if (data.success) {
                            alert(data.body);
                            location.reload();
                        } else {
                            alert(data.error);
                        }
                    },
                    error: function (jqXHR, textStatus, errorThrown) {

                        alert(errorThrown);
                        console.log(errorThrown);
                    }
                });

            });
    });

    var TempValue = $('#IdValue').val();
    if (TempValue == 0) {

        $('#sendMarksTableMail').prop('disabled', true);

    } else {
        $('#sendMarksTableMail').prop('disabled', false);

    }
   

});

$(function(){
    var timevalue = $('#timevalue').val();
    if (timevalue == 0) {

        $('#sendTimeTableMail').prop('disabled', true);

    } else {
        $('#sendTimeTableMail').prop('disabled', false);

    }
})
function getMarks(tempArray) {
    var myArray = [];
    var promises = [];
    // // Merge the contents of the two div elements
    // var mergedContent = $('#College'+ element.Count).html() + $('#marksData' + element.Count).html();

    // // Create a new hidden div to hold the merged content
    // var mergedDiv = $('<div>').html(mergedContent).css('display', 'none');

    tempArray.forEach(element => {
        var promise = new Promise(function (resolve, reject) {
            html2canvas(document.querySelector('#marksData' + element.Count))
                .then(function (canvas) {
                    var image = canvas.toDataURL();
                    var data = { email: element.email, Image: image };
                    myArray.push(data);
                    resolve();
                })
                .catch(function (error) {
                    reject(error);
                });
        });

        promises.push(promise);
    });

    Promise.all(promises)
        .then(function () {
            $.ajax({
                url: '../actions/admin_actions.php',
                type: 'post',
                data: {
                    myArray: JSON.stringify(myArray),
                    command: 'SentMarksInMail'
                },
                success: function (data, textStatus, jqXHR) {
                    console.log(data.error);
                    if (data.success) {
                        alert(data.body);
                        location.reload();
                    } else {
                        alert(data.error);
                    }
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    alert(errorThrown);
                    console.log(errorThrown);
                }
            });
        })
        .catch(function (error) {
            console.log(error);
        });

    console.log(myArray);
}