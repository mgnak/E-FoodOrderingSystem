$(function () {

    $('#btnAddStudentStrength').click(function () {
        $('#formAddUpdateStudentsStrength')[0].reset();
        $('#ssRid').val(0);
        $('#modalAddUpdateStudentsStrength').modal('show');
    });

    $('#btnSaveStudentsStrength').click(function (evt) {
        evt.preventDefault();

        var academicYear = $('#academicYear').val();
        var department = $('#department').val();
        var totalStudents = $('#totalStudents').val();

        if (academicYear === "-1") {
            alert("Please select academic year");
            return false;
        }

        if (totalStudents === "" || isNaN(totalStudents) || totalStudents === "0") {
            alert("Invalid value for students strength field");
            return false;
        }

        $.ajax({
            url: $('#formAddUpdateStudentsStrength').prop('action'),
            type: $('#formAddUpdateStudentsStrength').prop('method'),
            data: $('#formAddUpdateStudentsStrength').serialize(),
            success: function (data, textStatus, jqXHR) {
                if (data.success) {
                    alert(data.body);
                    location.reload();
                } else {
                    alert(data.error);
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                alert(errorThrown);
            }
        });
    });

});

function getStrengthDetails(strengthRid) {
    if (strengthRid) {
        $.ajax({
            url: '../actions/admin_actions.php',
            type: 'GET',
            data: {
                command: 'strengthDetails',
                strengthRid: strengthRid
            },
            success: function (data, textStatus, jqXHR) {
                if (data.success) {

                    var strength = data.body;

                    $('#addUpdateStudentsStrengthTitle').text('Update Students Strength');
                    $('#ssRid').val(strength.ss_rid);
                    $('#academicYear').val(strength.year);
                    $('#department').val(strength.dept_rid);
                    $('#totalStudents').val(strength.total_students);

                    $('#modalAddUpdateStudentsStrength').modal('show');

                } else {
                    alert(data.body);
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                alert(errorThrown);
            }
        });
    }
}