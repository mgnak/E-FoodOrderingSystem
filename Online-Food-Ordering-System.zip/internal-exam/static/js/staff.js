$(function () {

    $('#btnAddStaff').click(function (evt) {
        evt.preventDefault();
        $('#formAddUpdateStaff')[0].reset();
        $('#staffRid').val(0);
        $('#addUpdateStaffTitle').text('Add Staff');
        $('#modalAddUpdateStaff').modal('show');
    });

    $('#btnSaveStaff').click(function (evt) {
        evt.preventDefault();

        var staffName = $('#staffName').val();
        var shortName = $('#shortName').val();
        var contact = $('#contact').val();
        var emailId = $('#emailId').val();
        var password = $('#password').val();
        var department = $('#department').val();
        var address = $('#address').text();

        if (staffName === "") {
            alert("Please enter name");
            return false;
        }

        if (shortName === "") {
            alert("Please enter short name");
            return false;
        }

        if (contact === "" || contact.length !== 10 || isNaN(contact)) {
            alert("Please enter valid 10 digits contact");
            return false;
        }

        if (emailId === "") {
            alert("Please enter email");
            return false;
        }

        if (password === "") {
            alert("Please enter password");
            return false;
        }

        if (department === "-1") {
            alert("Please select department");
            return false;
        }

        if (address === "-1") {
            alert("Please enter address");
            return false;
        }

        $.ajax({
            url: $('#formAddUpdateStaff').prop('action'),
            type: $('#formAddUpdateStaff').prop('method'),
            data: $('#formAddUpdateStaff').serialize(),
            success: function (data, textStatus, jqXHR) {
                if (data.success) {
                    alert(data.body);
                    location.reload();
                } else {
                    alert(data.error);
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                alert(errorThrown);
            }
        });
    });
});

function getStaffDetails(staffRid) {
    if (staffRid) {
        $.ajax({
            url: '../actions/admin_actions.php',
            type: 'GET',
            data: {
                command: 'staffDetails',
                staffRid: staffRid
            },
            success: function (data, textStatus, jqXHR) {
                if (data.success) {

                    var staff = data.body;

                    $('#addUpdateStaffTitle').text('Update Staff');
                    $('#staffRid').val(staff.staff_rid);
                    $('#staffName').val(staff.name);
                    $('#shortName').val(staff.short_name);
                    $('#contact').val(staff.contact);
                    $('#emailId').val(staff.email);
                    $('#password').val(staff.password);
                    $('#department').val(staff.dept_rid);
                    $('#address').text(staff.address);

                    var isHoD = (parseInt(staff.is_hod) === 1);
                    $('#isHoD').prop('checked', isHoD);

                    $('#modalAddUpdateStaff').modal('show');

                } else {
                    alert(data.body);
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                alert(errorThrown);
            }
        });
    }
}