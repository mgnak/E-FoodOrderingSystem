$(function () {

    $('#btnLogin').click(function (evt) {
        evt.preventDefault();

        var loginId = $('#username').val();
        var password = $('#password').val();

        if (loginId === "") {
            alert("Please enter Roll no...");
            return false;
        }

        if (password === "") {
            alert("Please enter password...");
            return false;
        }

        $.ajax({
            url: $('#formLogin').prop('action'),
            type: $('#formLogin').prop('method'),
            data: $('#formLogin').serialize(),
            success: function (data, textStatus, jqXHR) {

                console.log(data);
                if (data.success) {

                    alert(data.body);
                    window.location.href = "../Student/timetable.php";

                } else {
                    alert(data.error);
                }

            },
            error: function (jqXHR, textStatus, errorThrown) {
                alert(errorThrown);
            }
        });




    });

});

$(function () {
    $('#btnRegister').click(function (evt) {
        evt.preventDefault();
        var phoneRegex = /^\d{10}$/;

        var loginId = $('#username').val();
        var password = $('#password').val();
        var contact = $('#contact').val();

        if (contact === "") {
            alert("Please enter contact number...");
            return false;
        }
        if (!phoneRegex.test(contact)) {
            alert("Please enter a valid phone number.");

            return false;
        }
        if (loginId === "") {
            alert("Please enter Roll no...");
            return false;
        }

        if (password === "") {
            alert("Please enter password...");
            return false;
        }

        $.ajax({
            url: $('#formRegister').prop('action'),
            type: $('#formRegister').prop('method'),
            data: $('#formRegister').serialize(),
            success: function (data, textStatus, jqXHR) {

                console.log(data);
                if (data.success) {
                    alert(data.body);
                    $('#formStudentLoginRedirect').submit();
                    window.location.href = "../Student/login.php";
                    // location.reload();
                } else {
                    alert(data.error);
                }

                // if (data.body.admin) {
                //     $('#formAdminLoginRedirect').submit();
                // } else if (data.body.office) {
                //     $('#formOfficeLoginRedirect').submit();
                // }
                // else {
                //     $('#formStaffLoginRedirect').submit();
                // }


            },
            error: function (jqXHR, textStatus, errorThrown) {
                alert(errorThrown);
            }
        });


    });

})