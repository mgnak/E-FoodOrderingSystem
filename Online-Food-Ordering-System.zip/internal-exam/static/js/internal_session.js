$(function () {

    $('#btnAddSession').click(function () {
        $('#formAddUpdateSession')[0].reset();
        $('#sessionRid').val(0);
        $('#addUpdateSessionTitle').val('Add Session');
        $('#modalAddUpdateSession').modal('show');
    });

    $('#btnSaveInternalSession').click(function (evt) {
        evt.preventDefault();

        var sessionNumber = $('#sessionNumber').val();
        var sessionDate = $('#sessionDate').val();
        var sessionTime = $('#sessionTime').val();

        if (sessionNumber === "" || isNaN(sessionNumber)) {
            alert("Invalid session number");
            return false;
        }

        if (sessionDate === "") {
            alert("Please enter valid date");
            return false;
        }

        if (sessionTime === "") {
            alert("Please enter valid time");
            return false;
        }

        $.ajax({
            url: $('#formAddUpdateSession').prop('action'),
            type: $('#formAddUpdateSession').prop('method'),
            data: $('#formAddUpdateSession').serialize(),
            success: function (data, textStatus, jqXHR) {

                if (data.success) {
                    alert(data.body);
                    location.reload();
                } else {
                    alert(data.error);
                }

            },
            error: function (jqXHR, textStatus, errorThrown) {
                alert(errorThrown);
            }
        });
    });
});

function getSessionDetails(sessionRid) {
    if (sessionRid) {
        $.ajax({
            url: '../actions/admin_actions.php',
            type: 'GET',
            data: {
                command: 'sessionDetails',
                sessionRid: sessionRid
            },
            success: function (data, textStatus, jqXHR) {
                if (data.success) {

                    var session = data.body;

                    $('#addUpdateSessionTitle').text('Update Session');
                    $('#sessionRid').val(session.session_rid);
                    $('#sessionNumber').val(session.number);
                    $('#sessionDate').val(session.display_date_format);
                    $('#sessionTime').val(session.time);
                    $('#remarks').val(session.remarks);

                    $('#modalAddUpdateSession').modal('show');

                } else {
                    alert(data.body);
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                alert(errorThrown);
            }
        });
    }
}