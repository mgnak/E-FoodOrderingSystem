<nav class="col-md-2 d-none d-md-block bg-light sidebar screen">
    <div class="sidebar-sticky">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="./timetable.php">
                    Time table
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="./marks.php">
                    Marks
                </a>
            </li>
        </ul>
    </div>
</nav>