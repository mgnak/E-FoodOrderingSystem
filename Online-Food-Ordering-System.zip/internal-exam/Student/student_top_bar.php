<nav class="navbar navbar-light fixed-top bg-white flex-md-nowrap p-0 shadow">
    <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="#"><b><?php echo 'Student' ?></b></a>
    <ul class="navbar-nav px-3">
        <li class="nav-item text-nowrap">
            <a class="nav-link" href="../staff/logout.php">Logout</a>
        </li>
    </ul>
</nav>