<?php
require_once '../include/config.php';
require_once '../db/DB.php';
require_once '../db/DepartmentManager.php';
require_once '../db/TimetableManager.php';
session_start();
$internal = 0;
$sem = 0;
$id= $_SESSION['student'][0]['id'];
$sem= $_SESSION['student'][0]['student_sem'];
if (isset($_GET['internal'])) {
    $internal = $_GET['internal'];
}


$Semister = array(1, 2, 3, 4, 5, 6);
$deptRid = 1;

$timeTable = TimetableManager::getTimeTableForStudent($sem, $internal);
$department = DepartmentManager::getDepartmentDetails($deptRid);
?>

<html>
<?php require_once '../include/head.php'; ?>

<body>

    <?php require_once './student_left_nav.php'; ?>

    <div class="container-fluid">
        <div class="row">

            <?php require_once './student_top_bar.php'; ?>

            <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
                <div class="row screen">
                    <h4 class="p-2">Time Table</h4>
                </div>
                <div class="row screen">
                    <form action="" method="get">
                        <div class="form-inline">
                            <label class="mr-1">Internal</label>
                            <select class="form-control-sm" id="internal" name="internal">
                                <option value="1" <?php $internal == 1 ? 'selected' : ''; ?>>1</option>
                                <option value="2" <?php $internal == 2 ? 'selected' : ''; ?>>2</option>
                                <option value="3" <?php $internal == 3 ? 'selected' : ''; ?>>3</option>
                            </select>

                            <!-- <label class="mr-1">Semister</label>

                            <select class="form-control" id="semister" name="semister">
                                <?php foreach ($Semister as $semister) { ?>
                                    <option value="<?php echo $semister ?>" <?php $sem == $semister ? 'selected' : ''; ?>><?php echo $semister ?> Semister</option>
                                <?php  } ?>

                            </select> -->
                            <button class="btn btn-primary btn-sm ml-1">
                                View Time Table
                            </button>
                           
                        </div>
                    </form>
                </div>
                <div class="print-area" id="time_tableData">
                    <?php if ($internal > 0) { ?>
                        <div class="row">
                            <table class="table table-borderless table-sm">
                                <tr>
                                    <td class="text-center">
                                        <strong><?php echo COLLEGE_Name?></strong>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="text-center">
                                        <strong>Department of <?php echo $department['name']; ?> Engineering</strong>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="text-center">
                                        <strong>
                                            <?php
                                            if ($internal == 1) {
                                                echo "First";
                                            } else if ($internal == 2) {
                                                echo "Second";
                                            } else if ($internal == 3) {
                                                echo "Third";
                                            }
                                            ?>
                                            Internal Time Table
                                        </strong>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    <?php } ?>
                    <div class="row">
                        <table class="table table-bordered table-sm">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Sem</th>
                                    <th>Subject</th>
                                    <th>Date</th>
                                    <th>Time</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $i = 0;
                                foreach ($timeTable as $tt) {
                                ?>
                                    <input type="text" value="<?php echo $tt['sem']; ?>" name="semi" id="semi" hidden>

                                    <tr>
                                        <td><?php echo ++$i; ?></td>
                                        <td><?php echo $tt['sem']; ?></td>
                                        <td><?php echo $tt['title']; ?></td>
                                        <td><?php echo $tt['formatted_date']; ?></td>
                                        <td><?php echo $tt['formatted_time']; ?></td>
                                    </tr>
                                <?php
                                }
                                if ($i == 0) {
                                ?>
                                    <tr>
                                        <td colspan="100%" class="alert alert-danger text-center">
                                            No records...
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <form id="SendTimeTableInMail" method="post" action="../actions/admin_actions.php"></form>
                <input type="hidden" value="SendInEmail" name="command">
                <!-- <div id="Spin" class="d-flex justify-content-center">
                    <div class="spinner-grow text-success" role="status">
                    </div>
                    <div class="spinner-grow text-danger" role="status">
                    </div>
                    <div class="spinner-grow text-warning" role="status">
                    </div>
                    <div class="spinner-grow text-info" role="status">
                    </div>
                </div> -->
                <!-- <div class="container d-flex justify-content-center mr-5">
                    <button class="btn btn-primary px-5" id="sendTimeTableMail" type="button">Send</button>
                </div> -->

            </main>
        </div>
    </div>

    <?php require_once '../include/footer.php'; ?>
    <script src="https://html2canvas.hertzen.com/dist/html2canvas.min.js"></script>

    <script src="../static/js/office.js"></script>
   
</body>

</html>