<?php

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASSWORD', 'mysql');
define('DB_NAME', 'internal_exam_db');

// admin user and password
define('ADMIN_LOGIN_ID', 'admin@gmail.com');
define('ADMIN_PASSWORD', 'admin');


// office user and password
define('OFFICE_LOGIN_ID', 'office@gmail.com');
define('OFFICE_PASSWORD', 'office');

define('COLLEGE_Name','St. Philomina College, Putter');

define('PROJECT_NAME', 'Internal Examination Supervision!');

