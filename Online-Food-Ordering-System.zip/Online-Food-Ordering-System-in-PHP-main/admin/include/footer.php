 <footer class="footer" style="text-align: center;"> © 2023 - Online Food Ordering System   </footer>
