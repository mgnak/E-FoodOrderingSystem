      <footer class="footer">
          <div class="container">


              <div class="bottom-footer">
                  <div class="row">
                      
                      <div class="col-xs-12 col-sm-4 address color-gray">
                          <h5>Address</h5>
                          <p>Nitte Canteeen, NMAMIT, Nitte.</p>
                          <h5>Phone: +91 01608445456</a></h5>
                      </div>
                      <div class="col-xs-12 col-sm-5 additional-info color-gray">
                          <h5>Addition informations</h5>
                          <p>Join thousands of other restaurants who benefit from having partnered with us.</p>
                      </div>
                  </div>
              </div>

          </div>
      </footer>


     